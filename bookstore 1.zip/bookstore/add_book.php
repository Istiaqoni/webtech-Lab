<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];

    $stmt = $conn->prepare("INSERT INTO books (title, author) VALUES (:title, :author)");
    $stmt->execute(['title' => $title, 'author' => $author]);

    header('Location: admin.php');
}
?>
