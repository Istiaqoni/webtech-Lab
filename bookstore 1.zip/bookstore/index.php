<?php
include 'db.php';

// Fetch available books
$stmt = $conn->prepare("SELECT * FROM books WHERE status = 'available'");
$stmt->execute();
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Online Bookstore</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Available Books</h1>
        <ul class="book-list">
            <?php foreach ($books as $book): ?>
                <li class="book-item">
                    <span class="book-title"><strong><?php echo $book['title']; ?></strong></span> by <span class="book-author"><?php echo $book['author']; ?></span>
                    <form class="borrow-form" action="borrow.php" method="POST">
                        <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                        <input type="text" name="student_name" placeholder="Your Name" required>
                        <button type="submit">Borrow</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
