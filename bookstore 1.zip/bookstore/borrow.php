<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_id = $_POST['book_id'];
    $student_name = $_POST['student_name'];
    $token = uniqid('token_');

    // Update book status
    $stmt = $conn->prepare("UPDATE books SET status = 'borrowed' WHERE id = :book_id");
    $stmt->execute(['book_id' => $book_id]);

    // Insert into borrowed_books table
    $stmt = $conn->prepare("INSERT INTO borrowed_books (book_id, student_name, token) VALUES (:book_id, :student_name, :token)");
    $stmt->execute([
        'book_id' => $book_id,
        'student_name' => $student_name,
        'token' => $token
    ]);

    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><?php echo "Book borrowed successfully! Your token no is: $token";?></h1>
</body>
</html>