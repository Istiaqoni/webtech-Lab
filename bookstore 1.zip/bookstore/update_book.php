<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_id = $_POST['book_id'];
    $title = $_POST['title'];
    $author = $_POST['author'];

    $stmt = $conn->prepare("UPDATE books SET title = :title, author = :author WHERE id = :book_id");
    $stmt->execute(['title' => $title, 'author' => $author, 'book_id' => $book_id]);

    header('Location: admin.php');
}
?>
