<?php
include 'db.php';

// Fetch all books
$stmt = $conn->prepare("SELECT * FROM books");
$stmt->execute();
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Online Bookstore</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Manage Books</h1>
        <form class="add-book-form" action="add_book.php" method="POST">
            <input type="text" name="title" placeholder="Book Title" required>
            <input type="text" name="author" placeholder="Author" required>
            <button type="submit">Add Book</button>
        </form>
        <ul class="book-list">
            <?php foreach ($books as $book): ?>
                <li class="book-item">
                    <div class="book-info">
                        <span class="book-title"><strong><?php echo $book['title']; ?></strong></span> by <span class="book-author"><?php echo $book['author']; ?></span>
                        <span class="book-status">(<?php echo $book['status']; ?>)</span>
                    </div>
                    <div class="book-actions">
                        <form class="update-form" action="update_book.php" method="POST">
                            <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                            <input type="text" name="title" value="<?php echo $book['title']; ?>" required>
                            <input type="text" name="author" value="<?php echo $book['author']; ?>" required>
                            <button class="update" type="submit">Update</button>
                        </form>
                        <form class="delete-form" action="delete_book.php" method="POST">
                            <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                            <button class="delete" type="submit">Delete</button>
                        </form>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
