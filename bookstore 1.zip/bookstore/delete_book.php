<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_id = $_POST['book_id'];

    try {
        // Check if the book is referenced in borrowed_books
        $stmt = $conn->prepare("SELECT COUNT(*) FROM borrowed_books WHERE book_id = :book_id");
        $stmt->execute(['book_id' => $book_id]);
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            // echo "Error: Cannot delete book because it is currently borrowed.";
        } else {
            // Delete the book from books table
            $stmt = $conn->prepare("DELETE FROM books WHERE id = :book_id");
            $stmt->execute(['book_id' => $book_id]);
            echo "Book deleted successfully.";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><?php echo "Cannot delete book because it is currently borrowed." ?></h1>
</body>
</html>